from __future__ import annotations

import argparse
import csv
import json
import time
from dataclasses import asdict
from pathlib import Path

from ntru_estimator import estimate as estimate_ntru
from parameters import PARAMETERS
from rsis_estimator import estimate as estimate_rsis


def _write_csv(path: Path, rows: list[dict]) -> None:
    with path.open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=rows[0].keys())
        writer.writeheader()
        writer.writerows(rows)


def main() -> None:
    parser = argparse.ArgumentParser(
        description="Run the DEdP25+PT26 progressive module-BKZ estimator."
    )
    parser.add_argument(
        "--quick",
        action="store_true",
        help="Use a reduced search for smoke testing; do not use for paper values.",
    )
    parser.add_argument(
        "--reuse",
        action="store_true",
        help="Reuse existing per-parameter JSON files under results/.",
    )
    args = parser.parse_args()

    root = Path(__file__).resolve().parent
    results = root / "results"
    results.mkdir(exist_ok=True)

    all_ntru: list[dict] = []
    all_rsis: list[dict] = []
    for parameter in PARAMETERS:
        for kind, estimator, aggregate in (
            ("ntru", estimate_ntru, all_ntru),
            ("rsis", estimate_rsis, all_rsis),
        ):
            result_path = results / f"{kind}_{parameter.n}.json"
            if args.reuse and result_path.exists():
                rows = json.loads(result_path.read_text(encoding="utf-8"))
            else:
                started = time.time()
                objects = estimator(parameter, quick=args.quick)
                rows = [asdict(item) for item in objects]
                result_path.write_text(
                    json.dumps(rows, indent=2),
                    encoding="utf-8",
                )
                print(
                    f"{kind} {parameter.n}: {time.time() - started:.2f} s",
                    flush=True,
                )
            aggregate.extend(rows)

    _write_csv(results / "ntru.csv", all_ntru)
    _write_csv(results / "rsis.csv", all_rsis)
    (results / "all_results.json").write_text(
        json.dumps({"ntru": all_ntru, "rsis": all_rsis}, indent=2),
        encoding="utf-8",
    )
    print("complete", flush=True)


if __name__ == "__main__":
    main()
