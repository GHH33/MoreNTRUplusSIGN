from __future__ import annotations

import math
from dataclasses import dataclass

import numpy as np
from scipy.special import digamma, gammaln

@dataclass(frozen=True)
class CyclotomicField:
    conductor: int
    degree: int
    discriminant: int
    roots_of_unity: int
    real_embeddings: int
    complex_embeddings: int


# K = Q(zeta_3) = Q(zeta_6): degree 2, discriminant 3.
ZETA3 = CyclotomicField(
    conductor=3,
    degree=2,
    discriminant=3,
    roots_of_unity=6,
    real_embeddings=0,
    complex_embeddings=2,
)


def log_unit_ball_volume(dim: float) -> float:
    return dim / 2.0 * math.log(math.pi) - gammaln(dim / 2.0 + 1.0)


def log_gh_z(dim: int) -> float:
    """Log Gaussian-heuristic radius for a determinant-one Z-lattice."""

    return (math.log(2.0) - np.euler_gamma - log_unit_ball_volume(dim)) / dim


def log_gh_k(K: CyclotomicField, rank: int) -> float:
    """DEdP25 number-field Gaussian heuristic, per rational dimension."""

    d = K.degree
    return log_gh_z(d * rank) + math.log(K.roots_of_unity / 2.0) / (d * rank)


def average_log_skewness(K: CyclotomicField, rank: int) -> float:
    """Spherical-model skewness correction used by the PT26 simulator."""

    d = K.degree
    dr = K.real_embeddings
    dc = K.complex_embeddings // 2
    log_nbb = (
        dr * digamma(rank / 2.0)
        + 2.0 * dc * (digamma(rank) - math.log(2.0))
        - d * digamma(d * rank / 2.0)
    )
    return log_nbb / (2.0 * d) + math.log(d) / 2.0
