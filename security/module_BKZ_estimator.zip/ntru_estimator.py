from __future__ import annotations

import math
from dataclasses import dataclass

import numpy as np

from costs import COST_MODELS
from geometry import cbd1_raw_canonical_norm_pmf, projected_norm_cdf
from number_field import ZETA3
from parameters import ParameterSet
from reduction import (
    module_block_radius,
    ntru_module_initial_profile,
    progressive_module_bkz_tour,
)

MODEL_NAME = "DEdP25+PT26 progressive module-BKZ"
TARGET_SUCCESS = 0.5


@dataclass(frozen=True)
class Result:
    parameter: str
    model: str
    cost_model: str
    cost_bits: float
    beta_q: int
    beta_k: int
    equation_rank_q: int
    success_probability: float
    radius: float
    metric: str
    note: str


def _success_curve(
    profile: np.ndarray,
    norm_squared: np.ndarray,
    norm_probabilities: np.ndarray,
    tours_per_beta: int,
    starting_beta_k: int,
    maximum_beta_k: int,
) -> list[tuple[int, int, float, float]]:
    """Cumulative fixed-target success along a progressive mBKZ schedule."""

    K = ZETA3
    rank_k = len(profile)
    dimension_q = K.degree * rank_k
    cumulative = np.zeros_like(norm_probabilities)
    current = profile.copy()

    for beta_k in range(3, min(starting_beta_k, maximum_beta_k + 1)):
        current = progressive_module_bkz_tour(
            current,
            beta_k,
            tours=tours_per_beta,
        )

    rows: list[tuple[int, int, float, float]] = []
    upper = min(maximum_beta_k, rank_k - 1)
    for beta_k in range(max(3, starting_beta_k), upper + 1):
        for _ in range(tours_per_beta):
            current = progressive_module_bkz_tour(current, beta_k, tours=1)
            radius = module_block_radius(current, rank_k - beta_k, beta_k)
            per_target = projected_norm_cdf(
                dimension_q,
                np.sqrt(norm_squared),
                K.degree * beta_k,
                radius,
            )
            cumulative += (1.0 - cumulative) * per_target

        rows.append(
            (
                beta_k,
                K.degree * beta_k,
                float(np.dot(norm_probabilities, cumulative)),
                radius,
            )
        )
    return rows


def _first_constant_success(
    rows: list[tuple[int, int, float, float]],
    cost_function,
) -> tuple[float, int, int, float, float] | None:
    candidates = [
        (cost_function(beta_q), beta_k, beta_q, probability, radius)
        for beta_k, beta_q, probability, radius in rows
        if probability >= TARGET_SUCCESS
    ]
    if not candidates:
        return None
    return min(candidates, key=lambda item: (item[2], item[1], -item[3]))


def _coarse_equation_ranks(secret_rank: int, quick: bool) -> list[int]:
    ratios = (
        (0.70, 0.775, 0.85, 0.925, 1.0)
        if quick
        else (
            0.55,
            0.60,
            0.65,
            0.70,
            0.725,
            0.75,
            0.775,
            0.80,
            0.825,
            0.85,
            0.875,
            0.90,
            0.925,
            0.95,
            0.975,
            1.0,
        )
    )
    return sorted(
        {
            max(1, min(secret_rank, int(round(secret_rank * ratio))))
            for ratio in ratios
        }
    )


def estimate(parameter: ParameterSet, quick: bool = False) -> list[Result]:
    """Estimate NTRU module-primal cost using only the combined model."""

    n = parameter.n
    q = parameter.q
    secret_rank_k = n // 2
    tours_per_beta = 2 if quick else 4
    maximum_beta_k = min(
        250 if quick else math.ceil(0.42 * n),
        n - 1,
    )

    records: dict[int, list[tuple[int, int, float, float]]] = {}
    for equation_rank_k in _coarse_equation_ranks(secret_rank_k, quick):
        norm_squared, probabilities = cbd1_raw_canonical_norm_pmf(
            secret_rank_k + equation_rank_k
        )
        profile = ntru_module_initial_profile(q, secret_rank_k, equation_rank_k)
        records[equation_rank_k] = _success_curve(
            profile,
            norm_squared,
            probabilities,
            tours_per_beta,
            starting_beta_k=20,
            maximum_beta_k=min(maximum_beta_k, len(profile) - 1),
        )

    # Refine locally around every cost model's best coarse equation rank.
    centers: set[int] = set()
    for cost_function in COST_MODELS.values():
        candidates = []
        for equation_rank_k, rows in records.items():
            optimum = _first_constant_success(rows, cost_function)
            if optimum is not None:
                candidates.append((*optimum, equation_rank_k))
        if not candidates:
            raise RuntimeError(f"No NTRU attack reached success 1/2 for {parameter.name}")
        centers.add(min(candidates, key=lambda item: item[0])[-1])

    radius = 3 if quick else 6
    for center in centers:
        for equation_rank_k in range(
            max(1, center - radius),
            min(secret_rank_k, center + radius) + 1,
        ):
            if equation_rank_k in records:
                continue
            norm_squared, probabilities = cbd1_raw_canonical_norm_pmf(
                secret_rank_k + equation_rank_k
            )
            profile = ntru_module_initial_profile(q, secret_rank_k, equation_rank_k)
            records[equation_rank_k] = _success_curve(
                profile,
                norm_squared,
                probabilities,
                tours_per_beta,
                starting_beta_k=20,
                maximum_beta_k=min(maximum_beta_k, len(profile) - 1),
            )

    output: list[Result] = []
    for cost_name, cost_function in COST_MODELS.items():
        candidates = []
        for equation_rank_k, rows in records.items():
            optimum = _first_constant_success(rows, cost_function)
            if optimum is not None:
                candidates.append((*optimum, equation_rank_k))
        cost, beta_k, beta_q, probability, block_radius, equation_rank_k = min(
            candidates,
            key=lambda item: item[0],
        )
        output.append(
            Result(
                parameter=parameter.name,
                model=MODEL_NAME,
                cost_model=cost_name,
                cost_bits=cost,
                beta_q=beta_q,
                beta_k=beta_k,
                equation_rank_q=2 * equation_rank_k,
                success_probability=probability,
                radius=block_radius,
                metric="raw K-canonical trace",
                note=(
                    "DEdP25 Q(zeta_3) geometry; PT26 finite-tour progressive "
                    f"module-BKZ; {tours_per_beta} tours/beta; exact unconditioned "
                    "CBD1 canonical-norm PMF; fixed-target success averaged after "
                    "the schedule; threshold p>=1/2"
                ),
            )
        )
    return output
