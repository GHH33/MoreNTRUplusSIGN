from __future__ import annotations

import math
from collections.abc import Callable


def svp_classical(beta_q: int | float) -> float:
    """Classical Core-SVP cost in bits."""

    return float(beta_q) * math.log(math.sqrt(3.0 / 2.0), 2.0)


def svp_quantum(beta_q: int | float) -> float:
    """Quantum Core-SVP cost in bits."""

    return 0.257 * float(beta_q)


def svp_plausible(beta_q: int | float) -> float:
    """Plausible/optimistic sieving cost in bits."""

    return float(beta_q) * math.log(math.sqrt(4.0 / 3.0), 2.0)


def sieve_log2_vectors(beta_q: int | float) -> float:
    """Log2 of the number of short vectors returned by a sieve."""

    return svp_plausible(beta_q)


COST_MODELS: dict[str, Callable[[int | float], float]] = {
    "classical": svp_classical,
    "quantum": svp_quantum,
    "plausible": svp_plausible,
}
