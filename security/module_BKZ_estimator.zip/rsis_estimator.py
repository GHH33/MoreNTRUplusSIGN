from __future__ import annotations

import math
from dataclasses import dataclass

from costs import COST_MODELS, sieve_log2_vectors
from geometry import (
    coefficient_valid_probability_given_raw_radius,
    log2_at_least_one,
    log_regular_head_success,
)
from number_field import ZETA3
from parameters import ParameterSet
from reduction import (
    module_block_radius,
    progressive_module_bkz_tour,
    rsis_randomized_initial_profile,
    rsis_regular_initial_profile,
)

MODEL_NAME = "DEdP25+PT26 progressive module-BKZ"
INFINITY = 9999.0


@dataclass(frozen=True)
class Result:
    parameter: str
    bound_name: str
    bound: float
    model: str
    branch: str
    cost_model: str
    cost_bits: float
    beta_q: int
    beta_k: int
    log2_single_probability: float
    log2_all_probability: float
    radius: float
    head_dimension_q: int
    metric: str
    note: str


def _module_cost(
    q: int,
    n: int,
    coefficient_bound: float,
    beta_k: int,
    cost_function,
    regular_profile,
    randomized_profile,
) -> tuple[float, str, float, float, float, int]:
    """Evaluate both RSIS branches with canonical-to-coefficient conversion."""

    beta_q = 2 * beta_k
    rational_dimension = 2 * n

    randomized_radius = module_block_radius(randomized_profile, 0, beta_k)
    randomized_probability = coefficient_valid_probability_given_raw_radius(
        randomized_radius,
        coefficient_bound,
        rational_dimension,
    )
    log2_randomized_single = (
        math.log(randomized_probability, 2.0)
        if randomized_probability > 0.0
        else -math.inf
    )
    log2_randomized_all = log2_at_least_one(
        log2_randomized_single,
        sieve_log2_vectors(beta_q),
    )
    randomized_cost = (
        cost_function(beta_q) + max(0.0, -log2_randomized_all)
        if math.isfinite(log2_randomized_all)
        else INFINITY
    )

    q_level = 2.0 * math.log(q) + 0.5 * math.log(3.0)
    head_rank_k = 0
    for value in regular_profile:
        if value >= q_level - 1e-8:
            head_rank_k += 1
        else:
            break

    regular_cost = INFINITY
    log2_regular_single = -math.inf
    log2_regular_all = -math.inf
    regular_radius = math.nan
    if head_rank_k < len(regular_profile):
        local_rank_k = min(beta_k, len(regular_profile) - head_rank_k)
        regular_radius = module_block_radius(
            regular_profile,
            head_rank_k,
            beta_k,
        )
        log_regular_single = log_regular_head_success(
            coefficient_bound,
            regular_radius,
            2 * head_rank_k,
            2 * local_rank_k,
            q,
        )
        log2_regular_single = log_regular_single / math.log(2.0)
        log2_regular_all = log2_at_least_one(
            log2_regular_single,
            sieve_log2_vectors(beta_q),
        )
        regular_cost = (
            cost_function(beta_q) + max(0.0, -log2_regular_all)
            if math.isfinite(log2_regular_all)
            else INFINITY
        )

    if randomized_cost <= regular_cost:
        return (
            randomized_cost,
            "randomized canonical sphere",
            log2_randomized_single,
            log2_randomized_all,
            randomized_radius,
            0,
        )
    return (
        regular_cost,
        "canonical tail + coefficient q-head",
        log2_regular_single,
        log2_regular_all,
        regular_radius,
        2 * head_rank_k,
    )


def estimate(parameter: ParameterSet, quick: bool = False) -> list[Result]:
    """Estimate both RSIS bounds using only the combined module-BKZ model."""

    n = parameter.n
    q = parameter.q
    tours_per_beta = 2 if quick else 4
    maximum_beta_q = min(2 * n - 1, 700 if quick else 1100)
    maximum_beta_k = maximum_beta_q // 2

    regular = rsis_regular_initial_profile(q, n // 2, n // 2)
    randomized = rsis_randomized_initial_profile(q, n // 2, n // 2)

    for beta_k in range(3, min(20, maximum_beta_k + 1)):
        regular = progressive_module_bkz_tour(
            regular,
            beta_k,
            tours=tours_per_beta,
        )
        randomized = progressive_module_bkz_tour(
            randomized,
            beta_k,
            tours=tours_per_beta,
        )

    bounds = (
        ("SelfTarget proxy", float(parameter.B_st)),
        ("CUR term", float(parameter.B_cur)),
    )
    best: dict[tuple[str, str], tuple] = {
        (bound_name, cost_name): (
            INFINITY,
            -1,
            "none",
            -math.inf,
            -math.inf,
            math.nan,
            0,
        )
        for bound_name, _ in bounds
        for cost_name in COST_MODELS
    }

    for beta_k in range(20, maximum_beta_k + 1):
        regular = progressive_module_bkz_tour(
            regular,
            beta_k,
            tours=tours_per_beta,
        )
        randomized = progressive_module_bkz_tour(
            randomized,
            beta_k,
            tours=tours_per_beta,
        )

        for bound_name, coefficient_bound in bounds:
            for cost_name, cost_function in COST_MODELS.items():
                candidate = _module_cost(
                    q,
                    n,
                    coefficient_bound,
                    beta_k,
                    cost_function,
                    regular,
                    randomized,
                )
                current = best[(bound_name, cost_name)]
                if candidate[0] < current[0]:
                    best[(bound_name, cost_name)] = (
                        candidate[0],
                        beta_k,
                        *candidate[1:],
                    )

    output: list[Result] = []
    for bound_name, coefficient_bound in bounds:
        for cost_name in COST_MODELS:
            (
                cost,
                beta_k,
                branch,
                log2_single,
                log2_all,
                radius,
                head_dimension_q,
            ) = best[(bound_name, cost_name)]
            output.append(
                Result(
                    parameter=parameter.name,
                    bound_name=bound_name,
                    bound=coefficient_bound,
                    model=MODEL_NAME,
                    branch=branch,
                    cost_model=cost_name,
                    cost_bits=cost,
                    beta_q=2 * beta_k,
                    beta_k=beta_k,
                    log2_single_probability=log2_single,
                    log2_all_probability=log2_all,
                    radius=radius,
                    head_dimension_q=head_dimension_q,
                    metric="raw K-canonical + coefficient output test",
                    note=(
                        "DEdP25 Q(zeta_3) geometry; PT26 finite-tour progressive "
                        f"module-BKZ; {tours_per_beta} tours/beta; exact Beta "
                        "angular conversion; coefficient q-head saddlepoint model"
                    ),
                )
            )
    return output
