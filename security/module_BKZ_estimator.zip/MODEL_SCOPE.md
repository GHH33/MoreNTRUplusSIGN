# Model scope

The package intentionally contains one structured-reduction model only:

```text
DEdP25 number-field Gaussian-heuristic geometry
+
PT26 finite-tour progressive module-BKZ simulation
```

The module field is `Q(zeta_3)`.  The DEdP25 contribution enters through the
field degree, discriminant, roots of unity, module Gaussian heuristic, and
skewness correction.  The PT26 contribution enters through the finite-tour
progressive profile update and the fixed-target success accumulation.

For NTRU, the target is the planted affine NTRU/Kannan vector and its
unconditioned CBD1 canonical-norm distribution is evaluated exactly.  For
RSIS, the output condition is in the coefficient norm, so the estimator
integrates the canonical ellipsoid rather than treating canonical and
coefficient radii as equal.

This remains a heuristic concrete estimator.  In particular, it does not
condition the NTRU key distribution on KeyGen acceptance, and it assumes
random orientation of reduced RSIS vectors in the canonical metric.
