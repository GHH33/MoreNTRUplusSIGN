import unittest

import numpy as np

from geometry import (
    cbd1_raw_canonical_norm_pmf,
    coefficient_valid_probability_given_raw_radius,
    qk,
)


class TestGeometry(unittest.TestCase):
    def test_qk_envelope(self):
        for u in range(-5, 6):
            for v in range(-5, 6):
                coefficient = u * u + v * v
                canonical = qk(u, v)
                self.assertLessEqual(0.5 * coefficient - 1e-12, canonical)
                self.assertLessEqual(canonical, 1.5 * coefficient + 1e-12)

    def test_angular_endpoints(self):
        self.assertEqual(
            coefficient_valid_probability_given_raw_radius(2.0, 0.1, 100),
            0.0,
        )
        self.assertEqual(
            coefficient_valid_probability_given_raw_radius(1.0, 2.0, 100),
            1.0,
        )

    def test_cbd_moment(self):
        values, probabilities = cbd1_raw_canonical_norm_pmf(100)
        self.assertAlmostEqual(float(np.dot(values, probabilities)), 202.0, places=8)


if __name__ == "__main__":
    unittest.main()
