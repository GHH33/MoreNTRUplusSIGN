import csv
import unittest
from pathlib import Path


class TestSavedResults(unittest.TestCase):
    def test_only_combined_model_is_saved(self):
        root = Path(__file__).resolve().parents[1] / "results"
        expected = "DEdP25+PT26 progressive module-BKZ"
        for filename in ("ntru.csv", "rsis.csv"):
            with (root / filename).open(newline="", encoding="utf-8") as handle:
                rows = list(csv.DictReader(handle))
            self.assertTrue(rows)
            self.assertEqual({row["model"] for row in rows}, {expected})


if __name__ == "__main__":
    unittest.main()
