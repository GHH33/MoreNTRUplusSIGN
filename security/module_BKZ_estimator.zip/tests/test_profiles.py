import unittest

from reduction import (
    progressive_module_bkz_tour,
    rsis_regular_initial_profile,
)


class TestProfiles(unittest.TestCase):
    def test_volume(self):
        profile = rsis_regular_initial_profile(101, 80, 80)
        reduced = progressive_module_bkz_tour(profile, 20, tours=2)
        self.assertAlmostEqual(float(profile.sum()), float(reduced.sum()), places=6)


if __name__ == "__main__":
    unittest.main()
