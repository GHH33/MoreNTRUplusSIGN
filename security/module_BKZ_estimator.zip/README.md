# NTRU+Sign DEdP25+PT26 progressive module-BKZ estimator

This is the stripped, single-backend version of the NTRU+Sign security
estimator.  It contains only

```text
DEdP25 number-field geometry
    +
PT26 finite-tour progressive module-BKZ
```

instantiated over

```text
K = Q(zeta_3),  [K:Q] = 2,  |Delta_K| = 3.
```

The legacy coefficient-GSA estimator, the PT26 ordinary-BKZ branch, and the
standalone DEdP25 converged-mGSA branch have been removed.

## What is estimated

* `ntru_estimator.py`: NTRU module-primal target recovery.
* `rsis_estimator.py`: the SelfTarget-RSIS proxy bound and the additional
  CUR-RSIS bound.
* `make_report.py`: component-wise and overall proxy summaries.

The fixed parameter sets are NTRU+Sign-648, -972, and -1296.  The corrected
RSIS bound is

```text
B_ST  = floor(B2 + (2^(d-1) + q0) * sqrt(n)),
B_CUR = 2 * B_ST.
```

## Canonical/coefficient treatment

For one `O_K` coordinate `u + v*zeta_6`, the normalized form is

```text
Q_K(u,v) = u^2 + uv + v^2,
```

and the raw trace norm is `2*Q_K`.  The NTRU branch uses the exact
raw-canonical norm PMF of the unconditioned CBD1 planted target.  The RSIS
branch integrates the canonical-to-coefficient ellipsoid instead of replacing
it by a scalar norm conversion:

```text
||x||_coef^2 / ||x||_K,can^2 = 1/3 + (2/3) S,
S ~ Beta(N/4, N/4).
```

This last step still uses the random-orientation heuristic in the canonical
metric.

## Run

```bash
python -m pip install -r requirements.txt
python run_all.py
python make_report.py
python -m unittest discover -s tests -v
```

For a smoke test only:

```bash
python run_all.py --quick
```

The checked full-search outputs are already under `results/`; reproduce the
report without rerunning the expensive search using:

```bash
python run_all.py --reuse
python make_report.py
```

## Scope

The NTRU target PMF is exact for unconditioned CBD1, but it is not conditioned
on the `g`-invertibility and `N_tau` KeyGen rejection tests.  The RSIS angular
conversion is exact under the canonical random-orientation heuristic, which
has not been validated specifically for this NTRU lattice family.  Costs are
Core-SVP estimates, not measured end-to-end attack times.
