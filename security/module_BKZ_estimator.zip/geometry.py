from __future__ import annotations

import math
from functools import lru_cache

import numpy as np
from scipy.optimize import brentq
from scipy.special import betainc, gammainc, gammaln, ndtr
from scipy.stats import beta as beta_dist


def qk(u: int | float, v: int | float) -> float:
    """Normalized Q(zeta_3) quadratic form u^2 + uv + v^2."""

    return float(u * u + u * v + v * v)


def coefficient_valid_probability_given_raw_radius(
    ell: float,
    coefficient_bound: float,
    rational_dimension: int,
) -> float:
    """Probability that a canonical-sphere direction meets a coefficient bound.

    The raw trace metric has Gram eigenvalues 1 and 3.  Consequently,

        ||x||_coef^2 / ||x||_K,can^2 = 1/3 + (2/3) S,
        S ~ Beta(N/4, N/4),

    under the random-orientation heuristic in rational dimension N.
    """

    if ell <= 0.0:
        return 1.0
    t = (3.0 * (coefficient_bound / ell) ** 2 - 1.0) / 2.0
    if t <= 0.0:
        return 0.0
    if t >= 1.0:
        return 1.0
    shape = rational_dimension / 4.0
    return float(betainc(shape, shape, t))


@lru_cache(maxsize=None)
def cbd1_raw_canonical_norm_pmf(number_of_k_coordinates: int) -> tuple[np.ndarray, np.ndarray]:
    """Exact raw-canonical squared-norm PMF of the CBD1 NTRU target.

    For one K-coordinate u + v*zeta_6, Q_K(u,v) takes 0, 1, 3 with
    probabilities 1/4, 5/8, 1/8.  The raw trace norm is 2*Q_K.  One
    Kannan K-coordinate contributes one further Q_K unit.
    """

    probability = np.asarray([1.0])
    for _ in range(number_of_k_coordinates):
        updated = np.zeros(len(probability) + 3)
        updated[: len(probability)] += 0.25 * probability
        updated[1 : 1 + len(probability)] += 0.625 * probability
        updated[3 : 3 + len(probability)] += 0.125 * probability
        probability = updated

    nonzero = np.flatnonzero(probability > 1e-16)
    low = max(0, int(nonzero[0]) - 2)
    high = min(len(probability), int(nonzero[-1]) + 3)
    probability = probability[low:high]
    probability /= probability.sum()

    qk_units = np.arange(low, high) + 1  # one Kannan unit
    return 2.0 * qk_units.astype(float), probability


def projected_norm_cdf(
    ambient_dimension: int,
    norm: np.ndarray,
    projected_dimension: int,
    radius: float,
) -> np.ndarray:
    """CDF of a fixed vector projected to a random subspace."""

    norm = np.asarray(norm, dtype=float)
    x = np.clip((radius / norm) ** 2, 0.0, 1.0)
    probability = betainc(
        projected_dimension / 2.0,
        (ambient_dimension - projected_dimension) / 2.0,
        x,
    )
    return np.where(radius >= norm, 1.0, probability)


def log2_at_least_one(log2_single_probability: float, log2_number: float) -> float:
    """Compute log2(1-(1-p)^N) stably from log2(p) and log2(N)."""

    if not math.isfinite(log2_single_probability):
        return -math.inf
    if log2_single_probability >= 0.0:
        return 0.0

    log_p = log2_single_probability * math.log(2.0)
    log_n = log2_number * math.log(2.0)
    if log_p < -30.0:
        log_t = log_n + log_p
    else:
        log_t = log_n + math.log(-math.log1p(-math.exp(log_p)))

    if log_t < -40.0:
        return log_t / math.log(2.0)
    if log_t > 40.0:
        return 0.0
    return math.log(-math.expm1(-math.exp(log_t)), 2.0)


def _tilted_uniform_square(t: float) -> tuple[float, float, float]:
    """CGF, mean and variance for a tilted U[0,1]^2 variable."""

    if abs(t) < 1e-10:
        return 0.0, 1.0 / 3.0, 4.0 / 45.0

    if t < 0.0:
        lam = -t
        logs: list[float] = []
        for k in range(3):
            shape = k + 0.5
            p = float(gammainc(shape, lam))
            if p <= 0.0:
                break
            logs.append(
                math.log(0.5)
                + gammaln(shape)
                + math.log(p)
                - shape * math.log(lam)
            )
        if len(logs) == 3:
            mean = math.exp(logs[1] - logs[0])
            second = math.exp(logs[2] - logs[0])
            return logs[0], mean, max(1e-300, second - mean * mean)

    nodes, weights = np.polynomial.legendre.leggauss(128)
    u = (nodes + 1.0) / 2.0
    weights = weights / 2.0
    exponent = t * u * u
    shift = float(np.max(exponent))
    values = weights * np.exp(exponent - shift)
    i0 = float(values.sum())
    i1 = float((values * u * u).sum())
    i2 = float((values * u**4).sum())
    mean = i1 / i0
    return shift + math.log(i0), mean, max(1e-300, i2 / i0 - mean * mean)


def log_cube_ball_cdf(dimension: int, radius: float, q: int) -> float:
    """Saddlepoint approximation to a centered q-cube/ball intersection."""

    if dimension <= 0:
        return 0.0 if radius >= 0.0 else -math.inf
    if radius <= 0.0:
        return -math.inf

    normalized_sum = (radius / (q / 2.0)) ** 2
    if normalized_sum >= dimension:
        return 0.0

    target_mean = normalized_sum / dimension
    mean = 1.0 / 3.0
    variance = 4.0 / 45.0
    if target_mean >= mean:
        z = (normalized_sum - dimension * mean) / math.sqrt(dimension * variance)
        return math.log(max(float(ndtr(z)), 1e-300))

    def equation(t: float) -> float:
        return _tilted_uniform_square(t)[1] - target_mean

    lower = -1.0
    while equation(lower) > 0.0:
        lower *= 4.0
        if lower < -1e12:
            break

    saddle = brentq(equation, lower, -1e-12)
    cgf, _, tilted_variance = _tilted_uniform_square(saddle)
    rate = saddle * target_mean - cgf
    w = -math.sqrt(max(0.0, 2.0 * dimension * rate))
    u = saddle * math.sqrt(dimension * tilted_variance)

    if w < -8.0:
        return (
            -dimension * rate
            - math.log(abs(saddle))
            - 0.5 * math.log(2.0 * math.pi * dimension * tilted_variance)
        )

    phi = math.exp(-w * w / 2.0) / math.sqrt(2.0 * math.pi)
    probability = float(ndtr(w)) + phi * (1.0 / w - 1.0 / u)
    if probability <= 0.0 or not math.isfinite(probability):
        return (
            -dimension * rate
            - math.log(abs(saddle))
            - 0.5 * math.log(2.0 * math.pi * dimension * tilted_variance)
        )
    return math.log(min(1.0, probability))


def log_regular_head_success(
    coefficient_bound: float,
    canonical_tail_radius: float,
    head_dimension: int,
    tail_dimension: int,
    q: int,
    integration_points: int = 65,
) -> float:
    """Integrate canonical-tail orientation and coefficient q-head success."""

    shape = tail_dimension / 4.0
    quantiles = (np.arange(integration_points) + 0.5) / integration_points
    beta_samples = beta_dist.ppf(quantiles, shape, shape)
    norm_ratios = 1.0 / 3.0 + 2.0 * beta_samples / 3.0

    log_probabilities: list[float] = []
    for ratio in norm_ratios:
        remaining = coefficient_bound**2 - canonical_tail_radius**2 * float(ratio)
        log_probabilities.append(
            log_cube_ball_cdf(head_dimension, math.sqrt(remaining), q)
            if remaining > 0.0
            else -math.inf
        )

    finite = np.asarray([x for x in log_probabilities if math.isfinite(x)])
    if len(finite) == 0:
        return -math.inf
    maximum = float(finite.max())
    return maximum + math.log(float(np.exp(finite - maximum).sum()) / integration_points)
