# Run metadata

- Reduction backend: **DEdP25+PT26 progressive module-BKZ only**.
- Number field: `K = Q(zeta_3)`, degree `2`, absolute discriminant `3`.
- Parameter sets were not changed.
- Manuscript Euclidean bounds: `B2 = 8500, 12520, 18185`.
- Corrected SelfTarget bounds use `2^(d-1)`:
  - `B_ST = 12751, 16728, 27653`
  - `B_CUR = 25502, 33456, 55306`
- Full search was run without `--quick`.
- NTRU: four finite module-BKZ tours per block size; exact unconditioned CBD1 raw-canonical norm PMF; fixed-target cumulative success threshold `p >= 1/2`.
- RSIS: four finite module-BKZ tours per block size; exact canonical/coefficient quadratic-form conversion under the canonical random-orientation heuristic; coefficient q-head saddlepoint model.
- Core-SVP costs follow the manuscript convention.
- The legacy coefficient GSA, PT26 ordinary BKZ, standalone DEdP25 converged mGSA, and legacy coefficient-guessing hybrid branches are absent from this package.
- Five regression tests passed.
