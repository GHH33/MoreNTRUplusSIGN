# DEdP25+PT26 progressive module-BKZ estimator 결과

이 패키지는 다른 reduction backend를 포함하지 않는다. 모든 결과는 $K=\mathbb Q(\zeta_3)$ 위의 DEdP25 number-field geometry와 PT26 finite-tour progressive module-BKZ simulator를 결합한 모델이다.

RSIS bound는 다음 corrected 식을 사용한다.

$$B_{\mathrm{ST}}=B_2+(2^{d-1}+q_0)\sqrt n,\qquad B_{\mathrm{CUR}}=2B_{\mathrm{ST}}.$$

각 셀은 `classical/quantum bits`이다.

| Component | 648 | 972 | 1296 |
|---|---:|---:|---:|
| NTRU module-primal | 122.84/107.94 ($\beta_\mathbb{Q}=420/420$) | 195.96/172.19 ($\beta_\mathbb{Q}=670/670$) | 277.86/244.15 ($\beta_\mathbb{Q}=950/950$) |
| SelfTarget-RSIS proxy | 111.15/97.67 ($\beta_\mathbb{Q}=380/380$) | 194.86/171.23 ($\beta_\mathbb{Q}=666/666$) | 254.48/223.61 ($\beta_\mathbb{Q}=870/870$) |
| Additional CUR-RSIS term | 74.34/65.32 ($\beta_\mathbb{Q}=254/254$) | 149.78/131.62 ($\beta_\mathbb{Q}=512/512$) | 160.36/140.92 ($\beta_\mathbb{Q}=548/548$) |

## Overall proxy

여기서는 NTRU module-primal, SelfTarget-RSIS proxy, challenge entropy의 최솟값을 UF proxy로 두고, CUR-RSIS를 추가한 최솟값을 SUF/CUR proxy로 둔다. 기존 coefficient-guessing hybrid attack은 이 stripped package에 포함하지 않았다.

| Parameter | UF proxy (classical/quantum) | SUF/CUR proxy (classical/quantum) |
|---|---:|---:|
| 648 | 111.15/97.67 (SelfTarget-RSIS proxy) | 74.34/65.32 (CUR-RSIS term) |
| 972 | 194.86/171.23 (SelfTarget-RSIS proxy) | 149.78/131.62 (CUR-RSIS term) |
| 1296 | 254.48/223.61 (SelfTarget-RSIS proxy) | 160.36/140.92 (CUR-RSIS term) |

## Metric handling

NTRU는 unconditioned CBD1 planted target의 exact raw-canonical norm PMF를 사용한다. RSIS는 canonical sphere에서 나온 vector가 coefficient-norm bound를 만족할 확률을 $Q_K(u,v)=u^2+uv+v^2$의 eigenstructure에 따른 Beta law로 적분한다. 따라서 canonical radius를 coefficient radius로 단순 치환하지 않는다.

모든 수치는 Core-SVP convention이며 measured wall-clock attack cost가 아니다.
