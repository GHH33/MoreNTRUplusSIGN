from __future__ import annotations

import argparse
import json
import time
from dataclasses import asdict
from pathlib import Path

from ntru_estimator import estimate as estimate_ntru
from parameters import PARAMETERS
from rsis_estimator import estimate as estimate_rsis


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("index", type=int, choices=range(len(PARAMETERS)))
    parser.add_argument("kind", choices=("ntru", "rsis"))
    parser.add_argument("--quick", action="store_true")
    args = parser.parse_args()

    parameter = PARAMETERS[args.index]
    estimator = estimate_ntru if args.kind == "ntru" else estimate_rsis
    started = time.time()
    rows = estimator(parameter, quick=args.quick)

    results = Path(__file__).resolve().parent / "results"
    results.mkdir(exist_ok=True)
    path = results / f"{args.kind}_{parameter.n}.json"
    path.write_text(
        json.dumps([asdict(item) for item in rows], indent=2),
        encoding="utf-8",
    )
    print(f"{path}: {time.time() - started:.2f} s")


if __name__ == "__main__":
    main()
