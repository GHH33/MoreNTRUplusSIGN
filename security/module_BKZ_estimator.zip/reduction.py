from __future__ import annotations

import math
from functools import lru_cache

import numpy as np

from number_field import CyclotomicField, ZETA3, average_log_skewness, log_gh_k


# PT26 experimental terminal mHKZ profile for K = Q(zeta_3).
_EXPERIMENTAL_MHKZ_ZETA3 = np.asarray(
    [
        0.9716492914337073,
        0.9114856980520094,
        0.8286796295672242,
        0.746669469677512,
        0.6627574926948221,
        0.5692110290104629,
        0.47777028806849886,
        0.38628579955920256,
        0.28871690892887075,
        0.19073887558242403,
        0.08927247889369598,
        -0.0113074058841222,
        -0.11319546179483703,
        -0.22595885044201752,
        -0.3368626118521294,
        -0.4412535483591159,
        -0.5486230624026852,
        -0.6525819046904507,
        -0.7432366678839547,
        -0.8802316490366664,
        -1.0269164496136993,
        -1.1430693495087514,
    ],
    dtype=float,
)


def _require_zeta3(K: CyclotomicField) -> None:
    if K != ZETA3:
        raise ValueError("This stripped estimator supports only K = Q(zeta_3).")


@lru_cache(maxsize=None)
def _module_gh_table(max_beta_k: int) -> np.ndarray:
    """PT26 local GH corrections with the DEdP25 field geometry."""

    K = ZETA3
    d = K.degree
    terminal_dimension = 45 // d
    experimental = _EXPERIMENTAL_MHKZ_ZETA3

    values: list[float] = [0.0]
    values.extend(
        float(experimental[-i] - np.sum(experimental[-i:]) / i)
        for i in range(1, terminal_dimension)
    )
    values.extend(
        d * log_gh_k(K, rank)
        + 0.5 * (math.log(K.discriminant) - d * math.log(d))
        + d * average_log_skewness(K, rank)
        for rank in range(terminal_dimension, max_beta_k + 1)
    )
    return np.asarray(values)


def progressive_module_bkz_tour(
    profile: np.ndarray,
    beta_k: int,
    tours: int = 1,
) -> np.ndarray:
    """One or more PT26 finite module-BKZ tours over Q(zeta_3)."""

    K = ZETA3
    _require_zeta3(K)
    current = np.asarray(profile, dtype=float).copy()
    rank = len(current)
    if beta_k < 2 or beta_k > rank:
        raise ValueError((beta_k, rank))

    terminal_dimension = min(45 // K.degree, beta_k)
    gh_table = _module_gh_table(beta_k)

    for _ in range(tours):
        old = current
        new = old.copy()
        old_prefix = np.concatenate(([0.0], np.cumsum(old)))
        new_prefix = np.zeros(rank + 1)
        changed = False
        boundary = rank - terminal_dimension

        for index in range(boundary):
            local_rank = min(beta_k, rank - index)
            final_index = min(index + beta_k - 1, rank - 1)
            local_volume = old_prefix[final_index + 1] - new_prefix[index]
            predicted = gh_table[local_rank] + local_volume / local_rank

            if not changed:
                if predicted < old[index]:
                    new[index] = predicted
                    changed = True
            else:
                new[index] = predicted
            new_prefix[index + 1] = new_prefix[index] + new[index]

        if not changed:
            break

        remaining_volume = float(np.sum(old) - np.sum(new[:boundary]))
        tail = _EXPERIMENTAL_MHKZ_ZETA3[-terminal_dimension:].copy()
        tail -= float(np.mean(tail))
        tail += remaining_volume / terminal_dimension
        new[boundary:] = tail

        volume_error = float(np.sum(old) - np.sum(new))
        new[boundary:] += volume_error / terminal_dimension
        if not np.isclose(np.sum(new), np.sum(old), atol=1e-7):
            raise ArithmeticError("module-BKZ tour did not preserve log-volume")
        current = new

    return current


def ntru_module_initial_profile(q: int, secret_rank: int, equation_rank: int) -> np.ndarray:
    """PT26-style initial profile for the affine NTRU module-Kannan lattice."""

    K = ZETA3
    d = K.degree
    rank = secret_rank + equation_rank + 1
    log_alpha = -2.0 * d * d * math.log(0.982)
    base = 0.5 * math.log(K.discriminant)
    target_volume = rank * base + equation_rank * d * math.log(q)
    q_level = d * math.log(q) + base

    transition = [
        q_level - i * log_alpha
        for i in range(1, int(d * math.log(q) / log_alpha) + 1)
    ]
    if len(transition) >= rank:
        profile = np.asarray(transition[-rank:], dtype=float)
        profile += (target_volume - float(np.sum(profile))) / rank
        return profile

    head: list[float] = []
    while (
        sum(transition) + sum(head) + q_level
        < target_volume - base * (rank - len(head) - len(transition) - 1)
        and len(head) + len(transition) < rank
    ):
        head.append(q_level)

    tail = [base] * (rank - len(head) - len(transition))
    profile = np.asarray(head + transition + tail, dtype=float)
    start = len(head)
    profile[start : start + len(transition)] += (
        target_volume - float(np.sum(profile))
    ) / len(transition)
    return profile


def rsis_regular_initial_profile(q: int, q_rank: int, unit_rank: int) -> np.ndarray:
    """Initial regular q-ary module profile in raw canonical metric."""

    K = ZETA3
    base = 0.5 * math.log(K.discriminant)
    return np.asarray(
        [K.degree * math.log(q) + base] * q_rank + [base] * unit_rank,
        dtype=float,
    )


def rsis_randomized_initial_profile(q: int, q_rank: int, unit_rank: int) -> np.ndarray:
    """Randomized q-ary module profile used by the RSIS sieve branch."""

    K = ZETA3
    d = K.degree
    rank = q_rank + unit_rank
    base = 0.5 * math.log(K.discriminant)
    log_delta = math.log(1.0 / 0.982)
    decrement = 2.0 * d * d * log_delta
    target_volume = q_rank * d * math.log(q)

    values: list[float] = []
    current = 0.0
    volume = 0.0
    for _ in range(rank):
        current += decrement
        volume += current
        if volume > target_volume:
            break
        values.insert(0, current)

    active = len(values)
    values += [0.0] * (rank - active)
    if active:
        error = sum(values) - target_volume
        values[:active] = [x - error / active for x in values[:active]]
    return np.asarray(values, dtype=float) + base


def module_block_radius(profile: np.ndarray, start: int, beta_k: int) -> float:
    """DEdP25/PT26 module-GH radius of a local terminal block."""

    K = ZETA3
    local_rank = min(beta_k, len(profile) - start)
    return math.exp(
        log_gh_k(K, local_rank)
        + float(np.sum(profile[start : start + local_rank]))
        / (K.degree * local_rank)
    )
