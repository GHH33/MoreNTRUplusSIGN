from __future__ import annotations

from dataclasses import dataclass


@dataclass(frozen=True)
class ParameterSet:
    """Fixed NTRU+Sign parameter set and estimator search limits."""

    name: str
    n: int
    q: int
    tau: int
    drop_bits: int
    q0: int
    B2: int
    B_st: int
    B_cur: int
    challenge_bits: int


# The RSIS bounds use B_st = floor(B2 + (2^(d-1) + q0) * sqrt(n))
# and B_cur = 2 * B_st, matching the corrected manuscript formula.
PARAMETERS = (
    ParameterSet(
        "NTRU+Sign-648", 648, 7129, 35, 8, 39,
        8500, 12751, 25502, 192,
    ),
    ParameterSet(
        "NTRU+Sign-972", 972, 9721, 38, 8, 7,
        12520, 16728, 33456, 227,
    ),
    ParameterSet(
        "NTRU+Sign-1296", 1296, 9721, 41, 9, 7,
        18185, 27653, 55306, 258,
    ),
)
