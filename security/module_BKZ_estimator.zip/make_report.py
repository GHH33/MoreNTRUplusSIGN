from __future__ import annotations

import csv
import json
import math
from pathlib import Path
from typing import Any

from ntru_estimator import MODEL_NAME

ROOT = Path(__file__).resolve().parent
RESULTS = ROOT / "results"
DATA = json.loads((RESULTS / "all_results.json").read_text(encoding="utf-8"))
NTRU: list[dict[str, Any]] = DATA["ntru"]
RSIS: list[dict[str, Any]] = DATA["rsis"]

PARAMETERS = ["NTRU+Sign-648", "NTRU+Sign-972", "NTRU+Sign-1296"]
SHORT = {name: name.rsplit("-", 1)[1] for name in PARAMETERS}
CHALLENGE_BITS = {
    "NTRU+Sign-648": 192,
    "NTRU+Sign-972": 227,
    "NTRU+Sign-1296": 258,
}


def ntru_row(parameter: str, cost_model: str) -> dict[str, Any]:
    rows = [
        row
        for row in NTRU
        if row["parameter"] == parameter
        and row["model"] == MODEL_NAME
        and row["cost_model"] == cost_model
    ]
    if len(rows) != 1:
        raise RuntimeError((parameter, cost_model, len(rows)))
    return rows[0]


def rsis_row(parameter: str, bound_name: str, cost_model: str) -> dict[str, Any]:
    rows = [
        row
        for row in RSIS
        if row["parameter"] == parameter
        and row["bound_name"] == bound_name
        and row["model"] == MODEL_NAME
        and row["cost_model"] == cost_model
    ]
    if len(rows) != 1:
        raise RuntimeError((parameter, bound_name, cost_model, len(rows)))
    return rows[0]


def overall(parameter: str, cost_model: str, include_cur: bool) -> dict[str, Any]:
    candidates = [
        {
            "component": "NTRU module-primal",
            "bits": float(ntru_row(parameter, cost_model)["cost_bits"]),
            "beta_q": int(ntru_row(parameter, cost_model)["beta_q"]),
        },
        {
            "component": "SelfTarget-RSIS proxy",
            "bits": float(rsis_row(parameter, "SelfTarget proxy", cost_model)["cost_bits"]),
            "beta_q": int(rsis_row(parameter, "SelfTarget proxy", cost_model)["beta_q"]),
        },
        {
            "component": "challenge entropy",
            "bits": float(CHALLENGE_BITS[parameter]),
            "beta_q": "",
        },
    ]
    if include_cur:
        candidates.append(
            {
                "component": "CUR-RSIS term",
                "bits": float(rsis_row(parameter, "CUR term", cost_model)["cost_bits"]),
                "beta_q": int(rsis_row(parameter, "CUR term", cost_model)["beta_q"]),
            }
        )
    return min(candidates, key=lambda item: item["bits"])


summary_rows: list[dict[str, Any]] = []
for parameter in PARAMETERS:
    for cost_model in ("classical", "quantum", "plausible"):
        ntru = ntru_row(parameter, cost_model)
        self_target = rsis_row(parameter, "SelfTarget proxy", cost_model)
        cur = rsis_row(parameter, "CUR term", cost_model)
        uf = overall(parameter, cost_model, include_cur=False)
        suf = overall(parameter, cost_model, include_cur=True)
        summary_rows.append(
            {
                "parameter": parameter,
                "model": MODEL_NAME,
                "cost_model": cost_model,
                "ntru_bits": float(ntru["cost_bits"]),
                "ntru_beta_q": int(ntru["beta_q"]),
                "selftarget_rsis_bits": float(self_target["cost_bits"]),
                "selftarget_rsis_beta_q": int(self_target["beta_q"]),
                "cur_rsis_bits": float(cur["cost_bits"]),
                "cur_rsis_beta_q": int(cur["beta_q"]),
                "uf_proxy_bits": uf["bits"],
                "uf_limiting_component": uf["component"],
                "suf_cur_proxy_bits": suf["bits"],
                "suf_limiting_component": suf["component"],
            }
        )

with (RESULTS / "summary.csv").open("w", newline="", encoding="utf-8") as handle:
    writer = csv.DictWriter(handle, fieldnames=list(summary_rows[0].keys()))
    writer.writeheader()
    writer.writerows(summary_rows)


def pair(component: str, parameter: str) -> str:
    if component == "NTRU":
        classical = ntru_row(parameter, "classical")
        quantum = ntru_row(parameter, "quantum")
    else:
        classical = rsis_row(parameter, component, "classical")
        quantum = rsis_row(parameter, component, "quantum")
    return (
        f"{float(classical['cost_bits']):.2f}/{float(quantum['cost_bits']):.2f} "
        f"($\\beta_\\mathbb{{Q}}={classical['beta_q']}/{quantum['beta_q']}$)"
    )


lines = [
    "# DEdP25+PT26 progressive module-BKZ estimator 결과",
    "",
    "이 패키지는 다른 reduction backend를 포함하지 않는다. 모든 결과는 "
    "$K=\\mathbb Q(\\zeta_3)$ 위의 DEdP25 number-field geometry와 PT26 "
    "finite-tour progressive module-BKZ simulator를 결합한 모델이다.",
    "",
    "RSIS bound는 다음 corrected 식을 사용한다.",
    "",
    "$$B_{\\mathrm{ST}}=B_2+(2^{d-1}+q_0)\\sqrt n,\\qquad "
    "B_{\\mathrm{CUR}}=2B_{\\mathrm{ST}}.$$",
    "",
    "각 셀은 `classical/quantum bits`이다.",
    "",
    "| Component | 648 | 972 | 1296 |",
    "|---|---:|---:|---:|",
    f"| NTRU module-primal | {pair('NTRU', PARAMETERS[0])} | "
    f"{pair('NTRU', PARAMETERS[1])} | {pair('NTRU', PARAMETERS[2])} |",
    f"| SelfTarget-RSIS proxy | {pair('SelfTarget proxy', PARAMETERS[0])} | "
    f"{pair('SelfTarget proxy', PARAMETERS[1])} | "
    f"{pair('SelfTarget proxy', PARAMETERS[2])} |",
    f"| Additional CUR-RSIS term | {pair('CUR term', PARAMETERS[0])} | "
    f"{pair('CUR term', PARAMETERS[1])} | {pair('CUR term', PARAMETERS[2])} |",
    "",
    "## Overall proxy",
    "",
    "여기서는 NTRU module-primal, SelfTarget-RSIS proxy, challenge entropy의 "
    "최솟값을 UF proxy로 두고, CUR-RSIS를 추가한 최솟값을 SUF/CUR proxy로 둔다. "
    "기존 coefficient-guessing hybrid attack은 이 stripped package에 포함하지 않았다.",
    "",
    "| Parameter | UF proxy (classical/quantum) | SUF/CUR proxy (classical/quantum) |",
    "|---|---:|---:|",
]
for parameter in PARAMETERS:
    uf_c = overall(parameter, "classical", False)
    uf_q = overall(parameter, "quantum", False)
    su_c = overall(parameter, "classical", True)
    su_q = overall(parameter, "quantum", True)
    lines.append(
        f"| {SHORT[parameter]} | {uf_c['bits']:.2f}/{uf_q['bits']:.2f} "
        f"({uf_c['component']}) | {su_c['bits']:.2f}/{su_q['bits']:.2f} "
        f"({su_c['component']}) |"
    )

lines += [
    "",
    "## Metric handling",
    "",
    "NTRU는 unconditioned CBD1 planted target의 exact raw-canonical norm PMF를 "
    "사용한다. RSIS는 canonical sphere에서 나온 vector가 coefficient-norm bound를 "
    "만족할 확률을 $Q_K(u,v)=u^2+uv+v^2$의 eigenstructure에 따른 Beta law로 "
    "적분한다. 따라서 canonical radius를 coefficient radius로 단순 치환하지 않는다.",
    "",
    "모든 수치는 Core-SVP convention이며 measured wall-clock attack cost가 아니다.",
]

(ROOT / "RESULTS_KO.md").write_text("\n".join(lines) + "\n", encoding="utf-8")
print(f"Wrote {ROOT / 'RESULTS_KO.md'}")
print(f"Wrote {RESULTS / 'summary.csv'}")
